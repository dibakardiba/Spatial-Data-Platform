package com.example.spatial.data.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpatialDataPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
